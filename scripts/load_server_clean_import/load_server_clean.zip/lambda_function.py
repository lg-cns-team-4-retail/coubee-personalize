import os
import time
import json
from sqlalchemy import create_engine, text, Table, MetaData, Column, Text, BIGINT
from sqlalchemy.schema import CreateSchema
from common.utils import get_personalize_client
from common.utils import get_s3_client
from common.utils import db_connection


def lambda_handler(event,context) -> dict:
    personalize_client = get_personalize_client()
    s3_client = get_s3_client()
    BUCKET_NAME = os.environ.get('OUTPUT_FOLDER')
    FILE_NAME = os.environ.get('FILE_KEY')
    
    try:
        etl_recommend(s3_client, BUCKET_NAME, FILE_NAME)
        clean_up(personalize_client)
    except Exception as e:
       return{
          "statusCode": 500,
          "body": ""
       }
    return{
       "statusCode": 200,
       "body": "s3 import/db 저장 완료 및 celan-up 완료"
    }

def etl_recommend(s3,bucket_name, file_key, ):
    recommendations_to_save = []
    response = s3.get_object(Bucket=bucket_name, Key=file_key)
    #  각 줄을 json line으로 변환시킴
    for line in response['Body'].iter_lines():
       res = json.loads(line)
       user_id = res['input']['userId']
       recommended_items = res['output']['recommendedItems']
       recommendations_to_save.append({
          "userId": user_id,
          "recommended_items" : recommended_items
       })

    #DB에 저장할 형태로 가공시킴
    insert_db = [
       {
          "user_id": data["userId"],
        #   json 문자열로 직렬화
          "recommend_items": json.dumps(data["recommended_items"])
       }
        for data in recommendations_to_save
    ]
    #Postgresql DB 연결 설정
    engine = db_connection()
    SCHEMA_NAME = "coubee_recommend"
    with engine.connect() as conn:
       #테이블 스키마 정의
       if not conn.dialect.has_schema(conn, SCHEMA_NAME):
            conn.execute(CreateSchema(SCHEMA_NAME))
            conn.commit()
       metadata = MetaData()
       recommendations_table = Table('recommend', metadata,
                                          Column('user_id', BIGINT, primary_key=True),
                                          Column('recommend_items', Text),
                                          schema=SCHEMA_NAME
                                         )
       #insert 실행
       conn.execute(recommendations_table.insert(), insert_db)
       #트랜잭션 커밋
       conn.commit()

# AWS 위에 Personalize 관련 인스턴스 모두 삭제
def clean_up(personalize) -> None: 
  DSG_ARN = personalize.list_dataset_groups()['datasetGroups'][0]['datasetGroupArn'] 
  SOLUTION_LIST = personalize.list_solutions( datasetGroupArn=DSG_ARN )['solutions'] 
  DS_LIST = personalize.list_datasets( datasetGroupArn=DSG_ARN )['datasets']

  for idx, solution in enumerate(SOLUTION_LIST): 
    response = personalize.delete_solution( 
      solutionArn=solution['solutionArn'] 
    )

  for idx, dataset in enumerate(DS_LIST): 
    response = personalize.delete_dataset( 
      datasetArn=dataset['datasetArn'] 
    )
  
  DS_LENGTH = 1 
  while DS_LENGTH > 0: 
    print("WAIT DS TO DELETE... :: ", DS_LENGTH) 
    time.sleep(30) 
    DS_LENGTH = len(personalize.list_datasets(datasetGroupArn=DSG_ARN)['datasets']) 
    response = personalize.delete_dataset_group( datasetGroupArn=DSG_ARN ) 
    print("DSG CLEAN UP")